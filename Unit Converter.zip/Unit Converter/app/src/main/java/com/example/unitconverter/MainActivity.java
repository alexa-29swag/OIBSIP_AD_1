package com.example.unitconverter;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText input;
    private Spinner unit;
    private TextView km, m, cm, mm, microm, nm, mile, yard, foot, inch;
    private DecimalFormat df;


    private static class UnitData {
        String name;
        String abbreviation;

        UnitData(String name, String abbreviation) {
            this.name = name;
            this.abbreviation = abbreviation;
        }

        @Override
        public String toString() {
            return abbreviation;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        df = new DecimalFormat("#.##########");


        initializeViews();
        setupSpinner();
        setupInputListener();

        updateConversions();
    }

    private void initializeViews() {
        input = findViewById(R.id.input);
        unit = findViewById(R.id.unit);
        km = findViewById(R.id.km);
        m = findViewById(R.id.m);
        cm = findViewById(R.id.cm);
        mm = findViewById(R.id.mm);
        microm = findViewById(R.id.microm);
        nm = findViewById(R.id.nm);
        mile = findViewById(R.id.mile);
        yard = findViewById(R.id.yard);
        foot = findViewById(R.id.foot);
        inch = findViewById(R.id.inch);
    }

    private void setupSpinner() {
        UnitData[] units = {
                new UnitData("Kilometers", "km"),
                new UnitData("Meters", "m"),
                new UnitData("Centimeters", "cm"),
                new UnitData("Millimeters", "mm"),
                new UnitData("Micrometers", "μm"),
                new UnitData("Nanometers", "nm"),
                new UnitData("Miles", "mi"),
                new UnitData("Yards", "yd"),
                new UnitData("Feet", "ft"),
                new UnitData("Inches", "in")
        };

        ArrayAdapter<UnitData> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                units
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unit.setAdapter(adapter);
        unit.setSelection(1);


        unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateConversions();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setupInputListener() {
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateConversions();
            }
        });
    }

    private void updateConversions() {
        String inputText = input.getText().toString().trim();


        if (inputText.isEmpty()) {
            clearAllResults();
            return;
        }

        try {
            double inputValue = Double.parseDouble(inputText);
            String selectedUnit = unit.getSelectedItem().toString();
            double meters = convertToMeters(inputValue, selectedUnit);


            setConversions(meters);

        } catch (NumberFormatException e) {
            clearAllResults();
        }
    }

    private double convertToMeters(double value, String fromUnit) {
        switch (fromUnit) {
            case "km":
                return value * 1000;
            case "m":
                return value;
            case "cm":
                return value / 100;
            case "mm":
                return value / 1000;
            case "μm":
                return value / 1_000_000;
            case "nm":
                return value / 1_000_000_000;
            case "mi":
                return value * 1609.34;
            case "yd":
                return value * 0.9144;
            case "ft":
                return value * 0.3048;
            case "in":
                return value * 0.0254;
            default:
                return value;
        }
    }

    private void setConversions(double meters) {

        double kilometers = meters / 1000;
        double centimeters = meters * 100;
        double millimeters = meters * 1000;
        double micrometers = meters * 1_000_000;
        double nanometers = meters * 1_000_000_000;
        double miles = meters / 1609.34;
        double yards = meters / 0.9144;
        double feet = meters / 0.3048;
        double inches = meters / 0.0254;


        km.setText(formatNumber(kilometers));
        m.setText(formatNumber(meters));
        cm.setText(formatNumber(centimeters));
        mm.setText(formatNumber(millimeters));
        microm.setText(formatNumber(micrometers));
        nm.setText(formatNumber(nanometers));
        mile.setText(formatNumber(miles));
        yard.setText(formatNumber(yards));
        foot.setText(formatNumber(feet));
        inch.setText(formatNumber(inches));
    }

    private String formatNumber(double number) {

        if (Math.abs(number) >= 1_000_000 || (Math.abs(number) < 0.01 && number != 0)) {
            return String.format("%.2e", number);
        } else {
            return df.format(number);
        }
    }

    private void clearAllResults() {
        km.setText("0");
        m.setText("0");
        cm.setText("0");
        mm.setText("0");
        microm.setText("0");
        nm.setText("0");
        mile.setText("0");
        yard.setText("0");
        foot.setText("0");
        inch.setText("0");
    }
}